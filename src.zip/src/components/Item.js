import React from "react";
import Date from "./Date";

export default function Item(props) {
    return (
        <div className="item">
            <div className="item_details">
                <div className="item_name">Song name: {props.name}</div>
                <Date date={props.date} />
                <div className="item_name">Description: {props.description} </div>
            </div>
            <img className="item_img" src={props.image} alt={props.name} />
        </div>
    );
}