import { useEffect, useState } from "react";
import Albums from "./Albums";

export default function Form() {
    const [songs, setSongs] = useState([]);

    useEffect(() => {
        const fetchAlbumData = async () => {
            try {
                const response = await fetch("https://www.theaudiodb.com/api/v1/json/2/album.php?i=112024");
                const result = await response.json();
                console.log(result);

                if (result.album && Array.isArray(result.album)) {
                    const songs = result.album;
                    const formattedSongs = songs.map(song => {
                        const randomMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, "0");
                        const randomDay = String(Math.floor(Math.random() * 28) + 1).padStart(2, "0");
                        const date = `${song.intYearReleased}/${randomMonth}/${randomDay}`;

                        return {
                            name: song.strAlbum,
                            description: song.strDescriptionEN || "No description available for this song",
                            image: song.strAlbumThumb,
                            date: date,
                        };
                    });

                    setSongs(formattedSongs);
                } else {
                    console.log("No album data found or invalid structure.");
                }
            } catch (err) {
                console.log(err);
            }
        };
        fetchAlbumData();

    }, []);

    if (songs.length === 0) {
        return (
            <div className="Form">
                <p>Unable to load songs.</p>
            </div>
        );
    }

    return (
        <div>
            <div className="Form">
                <Albums albums={songs} />
            </div>
        </div>
    );
}




// import { useEffect, useState } from "react";
// import Albums from "./Albums";

// export default function F() {
//     const [dataAlbum, setDataAlbum] = useState([]);
//     const [name, setName] = useState('');

//     useEffect(() => {

//         const fetchDataAlbum = async () => {

//             try {
//                 const response = await fetch("https://www.theaudiodb.com/api/v1/json/2/album.php?i=112024");
//                 const result = await response.json();
//                 console.log(result);

//                 const formatDataAlbum = result.data.map
//                     (album => ({
//                         name: album.strAlbum,
//                         date: album.intYearReleased,
//                         image: album.strAlbumThumb,
//                         description: album.strDescriptionEN,
//                     }))
//                 setDataAlbum(formatDataAlbum);
//             } catch (err) {
//                 console.log(err);
//             }
//         }
//         fetchDataAlbum()

//     }, []);




//     return (
//         <div>
//             <div className="F">
//                 <Albums albums={dataAlbum}></Albums>
//             </div>
//         </div>
//     )
// }