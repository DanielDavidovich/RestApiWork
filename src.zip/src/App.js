import './App.css';
import Form from "./components/Form";

export default function App() {

  return (
    <div className="App">
      <div>
        <Form />
      </div>
    </div>
  );
}
